package com.cirrent.agentclientsample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.cirrent.agentsdk.CirrentService;
import com.cirrent.agentsdk.EventAction;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CirrentService.AddIniCustomCallback {
    private EditText eventName;
    private Switch eventActionSwitch;
    private Spinner eventActionSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupViews();
    }

    private void setupViews() {
        eventName = (EditText) findViewById(R.id.event_name);
        eventActionSwitch = (Switch) findViewById(R.id.event_switch);
        eventActionSpinner = (Spinner) findViewById(R.id.event_spinner);

        setStateClickListener();
        setAttributeClickListener();
        setMeasurementClickListener();
        setupSwitchListener();
        setEventClickListener();
        setRegisterCallbackListener();
        setRegisterScriptListener();
        setSendCloudSyncOnClickListener();
    }

    private void setStateClickListener() {
        findViewById(R.id.send_state).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText stateName = (EditText) findViewById(R.id.state_name);
                EditText stateValue = (EditText) findViewById(R.id.state_value);
                CirrentService
                        .getCirrentService(getApplicationContext())
                        .addIniCustomState(
                                getCleanedText(stateName),
                                getCleanedText(stateValue),
                                MainActivity.this
                        );
            }
        });
    }

    private void setAttributeClickListener() {
        findViewById(R.id.send_attribute).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText attributeName = (EditText) findViewById(R.id.attribute_name);
                EditText attributeValue = (EditText) findViewById(R.id.attribute_value);
                CirrentService
                        .getCirrentService(getApplicationContext())
                        .addIniCustomAttribute(
                                getCleanedText(attributeName),
                                getCleanedText(attributeValue),
                                MainActivity.this
                        );
            }
        });
    }

    private void setMeasurementClickListener() {
        findViewById(R.id.send_measurement).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText measurementName = (EditText) findViewById(R.id.measurement_name);
                EditText measurementValue = (EditText) findViewById(R.id.measurement_value);
                try {
                    double value = Double.parseDouble(getCleanedText(measurementValue));
                    CirrentService
                            .getCirrentService(getApplicationContext())
                            .addIniCustomMeasurement(
                                    getCleanedText(measurementName),
                                    value,
                                    MainActivity.this
                            );
                } catch (NumberFormatException e) {
                    Toast.makeText(
                            MainActivity.this,
                            "Can't parse measurement value",
                            Toast.LENGTH_LONG
                    ).show();
                }
            }
        });
    }

    private void setupSwitchListener() {
        eventActionSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    eventActionSpinner.setVisibility(View.VISIBLE);
                    eventName.setText("custom_start_stop_event");
                } else {
                    eventActionSpinner.setVisibility(View.INVISIBLE);
                    eventName.setText("custom_instant_event");
                }
            }
        });
    }

    private void setEventClickListener() {
        findViewById(R.id.send_event).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String cleanedName = getCleanedText(eventName);
                if (eventActionSwitch.isChecked()) {
                    final String[] stringArray = getResources().getStringArray(R.array.eventSpinnerItems);
                    final String selectedAction = stringArray[eventActionSpinner.getSelectedItemPosition()];
                    final EventAction eventAction = selectedAction.equals(EventAction.START.toString()) ? EventAction.START : EventAction.STOP;
                    CirrentService
                            .getCirrentService(getApplicationContext())
                            .addIniCustomEvent(cleanedName, eventAction, MainActivity.this);
                } else {
                    CirrentService
                            .getCirrentService(getApplicationContext())
                            .addIniCustomEvent(cleanedName, MainActivity.this);
                }
            }
        });
    }

    private void setRegisterCallbackListener() {
        findViewById(R.id.register_callback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CirrentService
                        .getCirrentService(MainActivity.this)
                        .registerDiagnosticHandler(new CirrentService.DiagnosticHandlerCallback() {
                            @Override
                            public void onCallbackRegistered() {
                                showToast("Callback has been successfully registered");
                            }

                            @Override
                            public void onRequestReceived(String id, String type, String inputData) {
                                final String data = String.format(
                                        "id=%s; type=%s; inputData=%s;",
                                        id, type, inputData
                                );
                                showToast(data);
                                sendDataToCirrentAgentService(id, data);
                            }

                            @Override
                            public void onFailed(String errorMsg) {
                                showToast(errorMsg);
                            }
                        });
            }
        });
    }

    private void sendDataToCirrentAgentService(String id, String data) {
        CirrentService
                .getCirrentService(MainActivity.this)
                .sendDiagnosticResult(id, "SUCCESS", data, new CirrentService.DiagnosticResultSenderCallback() {
                    @Override
                    public void onResultSent() {
                        showToast("Diagnostic result has been successfully sent.");
                    }

                    @Override
                    public void onFailed(String errorMsg) {
                        showToast(errorMsg);
                    }
                });
    }

    private void setRegisterScriptListener() {
        findViewById(R.id.register_script).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText pathToScript = (EditText) findViewById(R.id.path_to_script);
                CirrentService
                        .getCirrentService(MainActivity.this)
                        .registerDiagnosticHandler(getCleanedText(pathToScript), new CirrentService.DiagnosticHandlerScriptCallback() {
                            @Override
                            public void onScriptRegistered() {
                                showToast("Diagnostic script has been successfully registered");
                            }

                            @Override
                            public void onFailed(String errorMsg) {
                                showToast(errorMsg);
                            }
                        });
            }
        });
    }

    private String getCleanedText(EditText editText) {
        return String.valueOf(editText.getText()).trim();
    }

    private void setSendCloudSyncOnClickListener() {
        findViewById(R.id.send_cloud_sync).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCloudSync();
            }
        });
    }

    private void sendCloudSync() {
        CirrentService
        .getCirrentService(getApplicationContext())
        .sendCloudSync(new CirrentService.CloudSyncCallback() {
            @Override
            public void onCloudSyncSent() {
                Log.i("CLOUD_SYNC", "SENT");
                Toast.makeText(
                    MainActivity.this,
                    "Cloud sync request sent",
                    Toast.LENGTH_SHORT
                ).show();
            }

            @Override
            public void onFailedCloudSync(String errorMsg) {
                Log.i("CLOUD_SYNC", "FAILED: " + errorMsg);
                Toast.makeText(MainActivity.this, errorMsg, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CirrentService.getCirrentService(getApplicationContext()).cancelAllTasks();
    }

    @Override
    public void onINIDataSent() {
        showToast("Data has been successfully sent");
    }

    @Override
    public void onFailedToSendData(String errorMsg) {
        showToast(errorMsg);
    }

    private void showToast(String msg) {
        Toast.makeText(
                this,
                msg,
                Toast.LENGTH_SHORT
        ).show();
    }
}
